#http://worldserver9.amazon.com/ws/upload_create_project?&token=19413089&openertoken=1473641804948&random=8610
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
#enable to select option from dropdownlist
from selenium.webdriver.support.ui import Select
import time, pyperclip
