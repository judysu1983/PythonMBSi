#http://worldserver9.amazon.com/ws/upload_create_project?&token=19413089&openertoken=1473641804948&random=8610
import webbrowser, sys
from selenium import webdriver

browser = webdriver.Firefox()
